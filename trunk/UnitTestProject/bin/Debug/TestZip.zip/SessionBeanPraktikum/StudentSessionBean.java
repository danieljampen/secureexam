/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myBeans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.*;
import javax.annotation.Resource;
import javax.ejb.*;
import javax.persistence.*;
import javax.sql.*;
import javax.sql.ConnectionPoolDataSource;
import org.eclipse.persistence.sessions.server.ConnectionPool;

/**
 *
 * @author Karl Rege / Ewald Mund   
 * HS2013
 */
//da muss was hin
@Remote(StudentSessionBeanRemote.class)
public class StudentSessionBean implements .............................. {
    
    
    
    private final static Logger logger = Logger.getLogger(StudentSessionBean.class.getName());
    
    //Da muss was hin
    DataSource studentDB;
    
    
    public StudentSessionBean() {
        super();
    }

    private Connection getConnection() {
        try {
             Connection con =  studentDB.getConnection();
             con.setAutoCommit(true);
             return con;
        }
        catch (Exception ex) {
            logger.severe(ex.toString());
            return null;
        }

    }

     public void create(Student student) throws Exception {
        Connection conn = getConnection(); 
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String query = "insert into student (vorname,name,strasse,plz,ort,semester,matrikel_nr) "
                    + " values('"+ student.getVorname() + "','"
                    + student.getName() + "','"
                    + student.getStrasse() + "','"
                    + student.getPlz() + "',' "
                    + student.getOrt() + "',"
                    + student.getSemester() + ",'"
                    + student.getMatrikelNr() + "' ) ";
            logger.info("create:"+query);
            int result = stmt.executeUpdate(query);
            logger.info("eingefügt:"+student);
        } catch (SQLException ex) {
           logger.severe("create  Fehler:" + ex);
           throw ex;
        } finally {
           conn.close();
           stmt.close();
        }

    }

    public void edit(Student student) throws Exception {
        Connection conn = getConnection();
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String query = "update student set "
                    + "vorname = '" + student.getVorname() + "' ,"
                    + "name =' " + student.getName() + "', "
                    + "strasse = ' " + student.getStrasse() + "', "
                    + "plz = '" + student.getPlz() + "',"
                    + "ort = '" + student.getOrt() + "',"
                    + "matrikel_nr = '" + student.getMatrikelNr() + "',"
                    + "semester =  " + student.getSemester() + " where id = "
                    + student.getId() + " ";
            logger.info("edit:"+query);
            int result = stmt.executeUpdate(query);

        } catch (SQLException ex) {
           logger.severe("edit  Fehler = " + ex);
           throw ex;
        } finally {
           conn.close();
           stmt.close();
        }
    }

    public void remove(Student student) throws Exception {
        Connection conn = getConnection();
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String query = "delete from student where id = " + student.getId() + " ";
            int result = stmt.executeUpdate(query);
        } catch (SQLException ex) {
           logger.severe("remove  Fehler = " + ex);
           throw ex;
        } finally {
           conn.close();
           stmt.close();
        }
    }

    public Student find(Object id) throws Exception  {
        Connection conn = getConnection();
        ResultSet rs = null;
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            int theId = (Integer) id;
            String query = "select * from STUDENT where id = " + theId + " ";
            rs = stmt.executeQuery(query);
            Student student = null;
            if (rs.next()) {
                student = new Student();
                student.setId(rs.getInt("id"));
                student.setVorname(rs.getString("vorname"));
                student.setName(rs.getString("name"));
                student.setStrasse(rs.getString("strasse"));
                student.setPlz(rs.getString("plz"));
                student.setOrt(rs.getString("ort"));
                student.setMatrikelNr(rs.getString("matrikel_nr"));
                student.setSemester(rs.getInt("semester"));
            }
            return student;


        } catch (SQLException ex) {
            logger.severe("findObject  Fehler = " + ex);
            throw ex;
        } finally {
            conn.close();
            rs.close();
            stmt.close();
        }
    }

    public List<Student> findAll() throws Exception {
        List<Student> result = new LinkedList<Student>();
        Connection conn = getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            System.out.println("FindALL 1");
            String query = "select * from student";
            rs = stmt.executeQuery(query);
            System.out.println("FindALL 2");
            

            while (rs.next()) {
                Student student = new Student();
                student.setId(rs.getInt("id"));
                student.setVorname(rs.getString("vorname"));
                student.setName(rs.getString("name"));
                student.setStrasse(rs.getString("strasse"));
                student.setPlz(rs.getString("plz"));
                student.setOrt(rs.getString("ort"));
                student.setMatrikelNr(rs.getString("matrikel_nr"));
                student.setSemester(rs.getInt("semester"));
                result.add(student);
            }
            return result;


        } catch (SQLException ex) {
            logger.severe("findall  Fehler = " + ex);
            throw ex;
         } finally {
            rs.close();
            stmt.close();
            conn.close();
         }

    }

    public List<Student> findRange(int[] range) throws Exception {

        return this.findAll();
    }

    @Override
    public int count() throws Exception {
        Connection con = getConnection();
        Statement stmt = null;
        try {
            stmt = con.createStatement();

            String query = "select count(*) from student  ";
            ResultSet rs = stmt.executeQuery(query);

            rs.next();
            return rs.getInt(1);
        } catch (SQLException ex) {
            logger.severe("count:" + ex);
            throw ex;
           
        } finally {
            con.close();
           
        }
      

    }
    
    public boolean isMatnrUnique(String matrikel_Nr, int id) {
         Connection conn = getConnection();
        Statement stmt;
        try {
            stmt = conn.createStatement();
            String query = "select count(*) from student where matrikel_nr = '" + matrikel_Nr +"'";
            
            if (id != 0) {                      //Student existiert schon
                query = "select count(*) from student where matrikel_nr = '" + matrikel_Nr +
                                          "' and id <> " + id;
            }
            ResultSet rs = stmt.executeQuery(query);

            rs.next();
            if (rs.getInt(1) == 0) return true;   //Nichts gefunden
            return false;
            
        } catch (SQLException ex) {
            logger.severe(matrikel_Nr);
        }
        
        return false;
    }
}
