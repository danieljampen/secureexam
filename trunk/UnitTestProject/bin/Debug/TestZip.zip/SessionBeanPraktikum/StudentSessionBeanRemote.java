/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myBeans;

import javax.ejb.Remote;
import java.util.*;

/**
 *
 * @author Karl Rege
 */
@Remote
public interface StudentSessionBeanRemote {
    public void edit(Student student) throws Exception;
    public void create(Student student) throws Exception;
    public void remove(Student student) throws Exception;
    public Student find(Object id)throws Exception ;
    public List<Student> findAll() throws Exception;
    public List<Student> findRange(int[] range)throws Exception ;
    public int count() throws Exception ;

    public boolean isMatnrUnique(String matrikelNr, int i) throws Exception;
   
}
